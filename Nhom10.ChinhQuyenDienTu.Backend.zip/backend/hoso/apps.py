from django.apps import AppConfig


class HosoConfig(AppConfig):
    name = 'hoso'
