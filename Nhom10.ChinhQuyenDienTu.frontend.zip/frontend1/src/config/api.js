export const urlApi = "https://backend.justfreshmen.team/";
export const urlApiFile = "https://backend.justfreshmen.team";
export const sdt = "0855603902";
