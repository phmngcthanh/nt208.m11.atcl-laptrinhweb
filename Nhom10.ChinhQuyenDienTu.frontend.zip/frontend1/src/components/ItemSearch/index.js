import React, { Component } from "react";

class ItemSearch extends Component {
  render() {
    return <div></div>;
  }
}

export default ItemSearch;
