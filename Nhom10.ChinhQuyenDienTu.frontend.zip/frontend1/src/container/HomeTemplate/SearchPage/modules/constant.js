export const SEARCH_HOSO_REQUEST = "searchHoSoReducer/SEARCH_HOSO_REQUEST";
export const SEARCH_HOSO_SUCCESS = "searchHoSoReducer/SEARCH_HOSO_SUCCESS";
export const SEARCH_HOSO_FAILED = "searchHoSoReducer/SEARCH_HOSO_FAILED";
