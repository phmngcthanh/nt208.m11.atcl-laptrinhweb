export const STATUS_HOSO_REQUEST = "statusHoSoReducer/STATUS_HOSO_REQUEST";
export const STATUS_HOSO_SUCCESS = "statusHoSoReducer/STATUS_HOSO_SUCCESS";
export const STATUS_HOSO_FAILED = "statusHoSoReducer/STATUS_HOSO_FAILED";
