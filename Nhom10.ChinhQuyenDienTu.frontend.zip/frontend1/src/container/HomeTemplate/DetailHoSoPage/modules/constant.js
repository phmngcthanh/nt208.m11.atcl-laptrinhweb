export const LIST_DETAILHOSO_REQUEST =
  "listDetailHoSoReducer/LIST_DETAILHOSO_REQUEST";
export const LIST_DETAILHOSO_SUCCESS =
  "listDetailHoSoReducer/LIST_DETAILHOSO_SUCCESS";
export const LIST_DETAILHOSO_FAILED =
  "listDetailHoSoReducer/LIST_DETAILHOSO_FAILED";
