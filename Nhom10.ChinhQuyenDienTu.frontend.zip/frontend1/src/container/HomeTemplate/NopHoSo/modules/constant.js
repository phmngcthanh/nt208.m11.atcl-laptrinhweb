//request
export const LIST_NOPHOSO_REQUEST = "listNopHoSoReducer/LIST_NOPHOSO_REQUEST";

//success
export const LIST_NOPHOSO_SUCCESS = "listNopHoSoReducer/LIST_NOPHOSO_SUCCESS";

//failed
export const LIST_NOPHOSO_FAILED = "listNopHoSoReducer/LIST_NOPHOSO_FAILED";
