export const USER_LOGIN_REQUEST = "userLoginReducer/USER_LOGIN_REQUEST";
export const USER_LOGIN_SUCCESS = "userLoginReducer/USER_LOGIN_SUCCESS";
export const USER_LOGIN_FAILED = "userLoginReducer/USER_LOGIN_FAILED";
export const USER_LOG_OUT = "userLoginReducer/USER_LOG_OUT";
