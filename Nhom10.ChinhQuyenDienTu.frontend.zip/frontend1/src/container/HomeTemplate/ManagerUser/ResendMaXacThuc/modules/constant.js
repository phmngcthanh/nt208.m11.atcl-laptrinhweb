export const USER_RESEND_REQUEST = "userResendReducer/USER_RESEND_REQUEST";
export const USER_RESEND_SUCCESS = "userResendReducer/USER_RESEND_SUCCESS";
export const USER_RESEND_FAILED = "userResendReducer/USER_RESEND_FAILED";
