export const USER_CREATE_REQUEST = "userCreateReducer/USER_CREATE_REQUEST";
export const USER_CREATE_SUCCESS = "userCreateReducer/USER_CREATE_SUCCESS";
export const USER_CREATE_FAILED = "userCreateReducer/USER_CREATE_FAILED";
