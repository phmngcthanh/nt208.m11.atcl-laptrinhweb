//request
export const QUESTION_REQUEST = "listQuestionReducer/QUESTION_REQUEST";

//success
export const QUESTION_SUCCESS = "listQuestionReducer/QUESTION_SUCCESS";

//failed
export const QUESTION_FAILED = "listQuestionReducer/QUESTION_FAILED";
