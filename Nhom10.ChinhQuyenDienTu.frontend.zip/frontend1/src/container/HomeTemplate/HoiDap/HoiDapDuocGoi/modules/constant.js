//request
export const LIST_QUESTION_REQUEST =
  "listQuestionUserReducer/LIST_QUESTION_REQUEST";

//success
export const LIST_QUESTION_SUCCESS =
  "listQuestionUserReducer/LIST_QUESTION_SUCCESS";

//failed
export const LIST_QUESTION_FAILED =
  "listQuestionUserReducer/LIST_QUESTION_FAILED";
