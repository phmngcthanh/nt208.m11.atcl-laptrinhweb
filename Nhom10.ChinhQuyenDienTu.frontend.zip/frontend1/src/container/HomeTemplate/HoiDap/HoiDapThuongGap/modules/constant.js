//request
export const LIST_QUESTION_THUONGGAP_REQUEST =
  "listQuestionThuongGapReducer/LIST_QUESTION_THUONGGAP_REQUEST";

//success
export const LIST_QUESTION_THUONGGAP_SUCCESS =
  "listQuestionThuongGapReducer/LIST_QUESTION_THUONGGAP_SUCCESS";

//failed
export const LIST_QUESTION_THUONGGAP_FAILED =
  "listQuestionThuongGapReducer/LIST_QUESTION_THUONGGAP_FAILED";
