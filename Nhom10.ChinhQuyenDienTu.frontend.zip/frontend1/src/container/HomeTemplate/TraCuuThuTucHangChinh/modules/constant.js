export const LIST_CATEGORY_REQUEST =
  "listCategoryReducer/LIST_CATEGORY_REQUEST";

export const LIST_CATEGORY_SUCCESS =
  "listCategoryReducer/LIST_CATEGORY_SUCCESS";
export const LIST_CATEGORY_FAILED = "listFieldReducer/LIST_CATEGORY_FAILED";

export const LIST_FIELD_REQUEST = "listFieldReducer/LIST_FIELD_REQUEST";
export const LIST_FIELD_SUCCESS = "listFieldReducer/LIST_FIELD_SUCCESS";
export const LIST_FIELD_FAILED = "listFieldReducer/LIST_FIELD_FAILED";

export const LIST_HOSO_REQUEST = "listHoSoReducer/LIST_HOSO_REQUEST";
export const LIST_HOSO_SUCCESS = "listHoSoReducer/LIST_HOSO_SUCCESS";
export const LIST_HOSO_FAILED = "listHoSoReducer/LIST_HOSO_FAILED";
