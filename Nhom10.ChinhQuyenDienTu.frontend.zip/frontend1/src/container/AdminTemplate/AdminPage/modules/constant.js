export const USER_LOGIN_REQUEST = "userLoginAdminReducer/USER_LOGIN_REQUEST";
export const USER_LOGIN_SUCCESS = "userLoginAdminReducer/USER_LOGIN_SUCCESS";
export const USER_LOGIN_FAILED = "userLoginAdminReducer/USER_LOGIN_FAILED";
export const USER_LOG_OUT = "userLoginAdminReducer/USER_LOG_OUT";
