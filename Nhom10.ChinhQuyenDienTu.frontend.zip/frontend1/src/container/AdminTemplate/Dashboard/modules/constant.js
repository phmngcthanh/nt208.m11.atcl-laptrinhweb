export const LIST_HOSO_REQUEST = "listHoSoReducer/LIST_HOSO_REQUEST";
export const LIST_HOSO_SUCCESS = "listHoSoReducer/LIST_HOSO_SUCCESS";
export const LIST_HOSO_FAILED = "listHoSoReducer/LIST_HOSO_FAILED";
