export const LIST_HOSO_REQUEST = "listKyHoSoReducer/LIST_HOSO_REQUEST";
export const LIST_HOSO_SUCCESS = "listKyHoSoReducer/LIST_HOSO_SUCCESS";
export const LIST_HOSO_FAILED = "listKyHoSoReducer/LIST_HOSO_FAILED";
